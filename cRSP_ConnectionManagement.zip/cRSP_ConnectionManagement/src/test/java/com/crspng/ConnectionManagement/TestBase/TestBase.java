package com.crspng.ConnectionManagement.TestBase;

import org.testng.annotations.BeforeTest;

import com.codoid.products.exception.FilloException;
import com.crspng.ConnectionManagement.commonFunctions.ExcelWrite;
import com.crspng.ConnectionManagement.commonFunctions.HttpMethods;

import io.restassured.RestAssured;

public class TestBase 
{
	public HttpMethods httpMethods;
	public ExcelWrite excelWrite;
	@BeforeTest
	public void initReferences() throws FilloException
	{
//		RestAssured.baseURI="https://crspiu1-crspng.eu1-int.mindsphere.io/api/crsp";
//		RestAssured.basePath="/v3";
		httpMethods = new HttpMethods();
		excelWrite = new ExcelWrite();
	}

}

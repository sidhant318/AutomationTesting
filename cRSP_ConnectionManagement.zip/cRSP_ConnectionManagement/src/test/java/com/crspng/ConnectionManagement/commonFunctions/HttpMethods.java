package com.crspng.ConnectionManagement.commonFunctions;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.asserts.SoftAssert;

import com.codoid.products.exception.FilloException;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class HttpMethods 
{
	SoftAssert sa;
	String sessionID;
//	ExcelWrite excelWrite;
	public HttpMethods()
	{
		sa = new SoftAssert();
//		excelWrite = new ExcelWrite();
	}
	
	public String createRDP(Object obj, int expectedStatusCode,String cookie,String x_xsrf_token)
	{
		Response response = RestAssured.given()
		.relaxedHTTPSValidation()
		.header("cookie", cookie)
		.header("Content-Type", ContentType.JSON)
		.header("x-xsrf-token", x_xsrf_token)
		.when()
		.body(obj)
		.post("https://crspiu1-crspng.eu1-int.mindsphere.io/api/crsp/v3/linkapi/connections");
		int statusCode = response.getStatusCode();
		long time = response.getTimeIn(TimeUnit.MILLISECONDS);
		System.out.println("--------"+statusCode);
		if(statusCode==202)
		{
			Reporter.log("--------  Collected for Create Conection Post Call "+" and time taken in milliseconds is "+time+"----------");
		}	
		else if(statusCode==400)
			Reporter.log("--------Request Parameters are incorrect for Conection Post Call----------");
		else
			Assert.assertEquals(statusCode, expectedStatusCode);
		return sessionID;
	}
	
	public Integer retrieveAllWebConnectionDetails(String cookie,String x_xsrf_token)
	{
		//Reporter.log("-------- Retrieving the session id : "+sessionID+"----------- for type "+appType+" and expected status is : "+expectedStatus);
		List<Integer> uid;
		Response response = RestAssured.given()
		.relaxedHTTPSValidation()
		.header("cookie", cookie)
		.header("Content-Type", ContentType.JSON)
		.header("x-xsrf-token", x_xsrf_token)
		.when()
		.get("https://crspiu1-crspng.eu1-int.mindsphere.io/api/crsp/v3/linkapi/connections");
		int statusCode = response.getStatusCode();
		uid=response.then().extract().path("data.uid_connection");
		String type = response.then().extract().path("description.type");
		String status = response.then().extract().path("status");
		if(statusCode==200 )//&& type.equals(appType) && status.equals(expectedStatus))
		{
			Reporter.log("-------Status Code is "+statusCode+"-----type is "+type+"-------status is "+status+"-----------Connection Id"+uid);
		}
		else
		{
			sa.assertEquals(statusCode, 204);
		//	sa.assertEquals(type, appType);
		//	sa.assertEquals(status, expectedStatus);
		}
		//Reporter.log("-------- Retrieved the session id : "+sessionID+"----------- for type "+appType+" and expected status is : "+expectedStatus);
		if(uid.size()>0) {
			return uid.get(0);
		}
		return null;
	}
	
	public void deleteWebConnectionDetails(String cookie,String x_xsrf_token,Integer connectionId)
	{
		Reporter.log("-------- Deleting the session id : "+sessionID+"-----------");
		Response response = RestAssured.given()
				.relaxedHTTPSValidation()
				.header("cookie", cookie)
				.header("Content-Type", ContentType.JSON)
				.header("x-xsrf-token", x_xsrf_token)
				.when()
				.delete("https://crspiu1-crspng.eu1-int.mindsphere.io/api/crsp/v3/linkapi/connections?id="+connectionId);
		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, 204);
		Reporter.log("--------Successfully deleted the connection id : "+connectionId+"--------");
	}

}

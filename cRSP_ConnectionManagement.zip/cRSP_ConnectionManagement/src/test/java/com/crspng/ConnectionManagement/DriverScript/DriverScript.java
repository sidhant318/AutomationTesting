package com.crspng.ConnectionManagement.DriverScript;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.crspng.ConnectionManagement.DataSet.SetWebConnectionParams;
import com.crspng.ConnectionManagement.Pojo.CreateConnectionRequest;
import com.crspng.ConnectionManagement.TestBase.TestBase;

public class DriverScript extends TestBase {
	CreateConnectionRequest createConnectionRequest=new CreateConnectionRequest();
	
	SetWebConnectionParams connectionParams = new SetWebConnectionParams();
	String Cookie="";// = "SESSION=ZWNhNjEyYjgtZTQ3NC00NmZmLWIyYWUtYmUzNGQ3OWFiYjY3; XSRF-TOKEN=9757c19a-a2bb-4703-a199-bd1935256708; REGION-SESSION=4f166d73-f0a2-4276-a925-bbfba62f7ade";
	String x_xsrf_token="";//="9757c19a-a2bb-4703-a199-bd1935256708";
	String sessionID;
	
	@BeforeClass
	public void getCookiesDetails() {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\BrowserServers\\chromedriver.exe");
		ChromeOptions options = new ChromeOptions();
	    options.setExperimentalOption("useAutomationExtension", false);
		WebDriver driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.get("https://crspiu1-crspng.eu1-int.mindsphere.io");
		driver.findElement(By.id("emailAddress")).sendKeys("crspnginteg@gmail.com");
		driver.findElement(By.id("passLogin")).sendKeys("Home@2019");
		driver.findElement(By.xpath("//span[contains(text(),'Sign In')]")).click();
		Set<org.openqa.selenium.Cookie> cookies = driver.manage().getCookies();
		for(org.openqa.selenium.Cookie c:cookies)
		{
			if(c.getName().equals("REGION-SESSION")||c.getName().equals("XSRF-TOKEN")||c.getName().equals("SESSION"))
				Cookie+=c.getName()+"="+c.getValue()+";";
			if(c.getName().equals("XSRF-TOKEN"))
				x_xsrf_token = c.getValue();
		}
		Cookie = Cookie.substring(0, Cookie.length()-1);
		System.out.println(Cookie);
		System.out.println(x_xsrf_token);
		
		driver.quit(); 
	}

	@Test(priority = 1, enabled = true, dataProvider="dataCollection_CreateRDP", dataProviderClass=com.crspng.ConnectionManagement.DataCollection.DataCollection.class)
	public void createRDPTest(String DeviceId, String AppInstanceId, String OpClientId, String username, String password) throws FilloException {
		//this.targetDevice=targetDevice;
		System.out.println(DeviceId+" - "+AppInstanceId+" - "+OpClientId+" - "+username+" - "+password+" - ");
		
		createConnectionRequest=connectionParams.setParameters(DeviceId, AppInstanceId, OpClientId, username, password);
		sessionID = httpMethods.createRDP(createConnectionRequest, 202,Cookie,x_xsrf_token);
	}
	@Test(priority = 2, enabled = true, dataProvider="dataCollection_CreateFailRDP", dataProviderClass=com.crspng.ConnectionManagement.DataCollection.DataCollection.class)
	public void createRDPFailTest(String DeviceId, String AppInstanceId, String OpClientId, String username, String password) throws FilloException {
		//this.targetDevice=targetDevice;
		System.out.println(DeviceId+" - "+AppInstanceId+" - "+OpClientId+" - "+username+" - "+password+" - ");
		createConnectionRequest=connectionParams.setParameters(DeviceId, AppInstanceId, OpClientId, username, password);
		sessionID = httpMethods.createRDP(createConnectionRequest, 400,Cookie,x_xsrf_token);
	}
	@Test(priority = 3, enabled = true)
	public void getAllWebSessionDetailsTest() 
	{
		Integer connectionId=httpMethods.retrieveAllWebConnectionDetails(Cookie,x_xsrf_token);
		System.out.println(" -------------     "+connectionId);
		if(connectionId!=null) {
			httpMethods.retrieveAllWebConnectionDetails(Cookie,x_xsrf_token);
		}
	}
	
	
	
	
	
	@Test(priority = 4, enabled = true, dataProvider="dataCollection_PROXYUNAWARE", dataProviderClass=com.crspng.ConnectionManagement.DataCollection.DataCollection.class)
	public void createPUTest(String DeviceId, String AppInstanceId, String OpClientId, String username, String password) throws FilloException {
		//this.targetDevice=targetDevice;
		System.out.println(DeviceId+" - "+AppInstanceId+" - "+OpClientId+" - "+username+" - "+password+" - ");
		createConnectionRequest=connectionParams.setParameters(DeviceId, AppInstanceId, OpClientId, username, password);
		sessionID = httpMethods.createRDP(createConnectionRequest, 202,Cookie,x_xsrf_token);
	}
	
	@Test(priority = 5, enabled = true, dataProvider="dataCollection_PROXYUNAWARE_Fail", dataProviderClass=com.crspng.ConnectionManagement.DataCollection.DataCollection.class)
	public void createPUFailTest(String DeviceId, String AppInstanceId, String OpClientId, String username, String password) throws FilloException {
		//this.targetDevice=targetDevice;
		System.out.println(DeviceId+" - "+AppInstanceId+" - "+OpClientId+" - "+username+" - "+password+" - ");
		createConnectionRequest=connectionParams.setParameters(DeviceId, AppInstanceId, OpClientId, username, password);
		sessionID = httpMethods.createRDP(createConnectionRequest, 202,Cookie,x_xsrf_token);
	}
	
	@Test(priority = 6, enabled = true, dataProvider="dataCollection_BACNETIP", dataProviderClass=com.crspng.ConnectionManagement.DataCollection.DataCollection.class)
	public void createBACNETIPTest(String DeviceId, String AppInstanceId, String OpClientId, String username, String password) throws FilloException {
		//this.targetDevice=targetDevice;
		System.out.println(DeviceId+" - "+AppInstanceId+" - "+OpClientId+" - "+username+" - "+password+" - ");
		createConnectionRequest=connectionParams.setParameters(DeviceId, AppInstanceId, OpClientId, username, password);
		sessionID = httpMethods.createRDP(createConnectionRequest, 202,Cookie,x_xsrf_token);
	}
	
	@Test(priority = 7, enabled = true, dataProvider="dataCollection_BACNETIP_Fail", dataProviderClass=com.crspng.ConnectionManagement.DataCollection.DataCollection.class)
	public void createBACNETIPFailTest(String DeviceId, String AppInstanceId, String OpClientId, String username, String password) throws FilloException {
		//this.targetDevice=targetDevice;
		System.out.println(DeviceId+" - "+AppInstanceId+" - "+OpClientId+" - "+username+" - "+password+" - ");
		createConnectionRequest=connectionParams.setParameters(DeviceId, AppInstanceId, OpClientId, username, password);
		sessionID = httpMethods.createRDP(createConnectionRequest, 202,Cookie,x_xsrf_token);
	}
	
	@Test(priority = 8, enabled = true, dataProvider="dataCollection_CreateWebApp", dataProviderClass=com.crspng.ConnectionManagement.DataCollection.DataCollection.class)
	public void createTRANSPARENTTest(String DeviceId, String AppInstanceId, String OpClientId, String username, String password) throws FilloException {
		//this.targetDevice=targetDevice;
		System.out.println(DeviceId+" - "+AppInstanceId+" - "+OpClientId+" - "+username+" - "+password+" - ");
		createConnectionRequest=connectionParams.setParameters(DeviceId, AppInstanceId, OpClientId, username, password);
		sessionID = httpMethods.createRDP(createConnectionRequest, 202,Cookie,x_xsrf_token);
	}
	
	@Test(priority = 9, enabled = true, dataProvider="dataCollection_CreateWebApp_Fail", dataProviderClass=com.crspng.ConnectionManagement.DataCollection.DataCollection.class)
	public void createTRANSPARENTFailTest(String DeviceId, String AppInstanceId, String OpClientId, String username, String password) throws FilloException {
		//this.targetDevice=targetDevice;
		System.out.println(DeviceId+" - "+AppInstanceId+" - "+OpClientId+" - "+username+" - "+password+" - ");
		createConnectionRequest=connectionParams.setParameters(DeviceId, AppInstanceId, OpClientId, username, password);
		sessionID = httpMethods.createRDP(createConnectionRequest, 202,Cookie,x_xsrf_token);
	}
	
	@Test(priority = 10, enabled = true, dataProvider="dataCollection_WEBRDP", dataProviderClass=com.crspng.ConnectionManagement.DataCollection.DataCollection.class)
	public void createWEBRDPTest(String DeviceId, String AppInstanceId, String OpClientId, String username, String password) throws FilloException {
		//this.targetDevice=targetDevice;
		System.out.println(DeviceId+" - "+AppInstanceId+" - "+OpClientId+" - "+username+" - "+password+" - ");
		createConnectionRequest=connectionParams.setParameters(DeviceId, AppInstanceId, OpClientId, username, password);
		sessionID = httpMethods.createRDP(createConnectionRequest, 202,Cookie,x_xsrf_token);
	}
	
	@Test(priority = 11, enabled = true, dataProvider="dataCollection_WEBRDP_Fail", dataProviderClass=com.crspng.ConnectionManagement.DataCollection.DataCollection.class)
	public void createWEBRDPFailTest(String DeviceId, String AppInstanceId, String OpClientId, String username, String password) throws FilloException {
		//this.targetDevice=targetDevice;
		System.out.println(DeviceId+" - "+AppInstanceId+" - "+OpClientId+" - "+username+" - "+password+" - ");
		createConnectionRequest=connectionParams.setParameters(DeviceId, AppInstanceId, OpClientId, username, password);
		sessionID = httpMethods.createRDP(createConnectionRequest, 202,Cookie,x_xsrf_token);
	}

//	@AfterMethod
//	public void afterMethod(ITestResult result) throws FilloException
//	{
//		if(sessionID!=null && result.getStatus()==ITestResult.SUCCESS)
//			excelWrite.excelUpdate(sessionID, "Pass", targetDevice);
//		if(sessionID!=null && result.getStatus()==ITestResult.FAILURE)
//			excelWrite.excelUpdate(sessionID, "Fail", targetDevice);
//	}

}

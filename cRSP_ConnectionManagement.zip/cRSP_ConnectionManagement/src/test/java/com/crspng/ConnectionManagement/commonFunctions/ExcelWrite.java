package com.crspng.ConnectionManagement.commonFunctions;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;

public class ExcelWrite {
	Fillo fillo;
	Connection connection;
	String excelPath = System.getProperty("user.dir")+"\\TestData\\TestData2.xlsx";
	public ExcelWrite() throws FilloException
	{
		fillo = new Fillo();
		connection = fillo.getConnection(excelPath);
	}
	public void excelUpdate(String sessionID, String status, String targetDevice) throws FilloException
	{
		String updateQuery = "update sheet1 set SessionID = '"+sessionID+"', teststatus = '"+status+"' where targetdevice = '"+targetDevice+"'";
		connection.executeUpdate(updateQuery);
	}

}

package com.crspng.ConnectionManagement.DataCollection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.testng.Reporter;
import org.testng.annotations.DataProvider;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

public class DataCollection {
	
	Fillo fillo;
	Connection connection;
	String excelPath = System.getProperty("user.dir")+"\\TestData\\TestData2.xlsx";
	public DataCollection() throws FilloException
	{
		fillo = new Fillo();
		connection = fillo.getConnection(excelPath);
	}
	
	@DataProvider(name="dataCollection_CreateRDP")
	public Iterator<String[]> dataCollectionRDPParams() throws FilloException
	{
		List<String[]> lst = new ArrayList<>();
		String query = "select DeviceId, AppInstanceId, OpClientId, username, password from sheet1 where flag = 'Y' and scenario = 'CreateRDP'";
		try
		{
			Recordset rs = connection.executeQuery(query);
			if(rs!=null)
			{
				while(rs.next())
				{
					String[] str = new String[5];
					str[0]=rs.getField("DeviceId");
					str[1]=rs.getField("AppInstanceId");
					str[2]=rs.getField("OpClientId");
					str[3]=rs.getField("username");
					str[4]=rs.getField("password");
					lst.add(str);
				}
			}
			Reporter.log("------ Getting Null values ------");
		}
		catch(NullPointerException e)
		{
			Reporter.log("------ Getting Null values ------");
		}
		catch(Exception e)
		{
			Reporter.log("------ Not Getting proper values ------");
		}
		return lst.iterator();
	}
	
	@DataProvider(name="dataCollection_CreateFailRDP")
	public Iterator<String[]> dataCollectionRDPFail() throws FilloException
	{
		List<String[]> lst = new ArrayList<>();
		String query = "select DeviceId, AppInstanceId, OpClientId, username, password from sheet1 where flag = 'Y' and scenario = 'CreateRDPFail'";
		try
		{
			Recordset rs = connection.executeQuery(query);
			if(rs!=null)
			{
				while(rs.next())
				{
					String[] str = new String[5];
					str[0]=rs.getField("DeviceId");
					str[1]=rs.getField("AppInstanceId");
					str[2]=rs.getField("OpClientId");
					str[3]=rs.getField("username");
					str[4]=rs.getField("password");
					lst.add(str);
				}
			}
			Reporter.log("------ Getting Null values ------");
		}
		catch(NullPointerException e)
		{
			Reporter.log("------ Getting Null values ------");
		}
		catch(Exception e)
		{
			Reporter.log("------ Not Getting proper values ------");
		}
		return lst.iterator();
	}
	
	/////////////////
	
	@DataProvider(name="dataCollection_PROXYUNAWARE")
	public Iterator<String[]> dataCollectionPU() throws FilloException
	{
		List<String[]> lst = new ArrayList<>();
		String query = "select DeviceId, AppInstanceId, OpClientId, username, password from sheet1 where flag = 'Y' and scenario = 'CreatePU'";
		try
		{
			Recordset rs = connection.executeQuery(query);
			if(rs!=null)
			{
				while(rs.next())
				{
					String[] str = new String[5];
					str[0]=rs.getField("DeviceId");
					str[1]=rs.getField("AppInstanceId");
					str[2]=rs.getField("OpClientId");
					str[3]=rs.getField("username");
					str[4]=rs.getField("password");
					lst.add(str);
				}
			}
			Reporter.log("------ Getting Null values ------");
		}
		catch(NullPointerException e)
		{
			Reporter.log("------ Getting Null values ------");
		}
		catch(Exception e)
		{
			Reporter.log("------ Not Getting proper values ------");
		}
		return lst.iterator();
	}
	
	@DataProvider(name="dataCollection_PROXYUNAWARE_Fail")
	public Iterator<String[]> dataCollectionPUFail() throws FilloException
	{
		List<String[]> lst = new ArrayList<>();
		String query = "select DeviceId, AppInstanceId, OpClientId, username, password from sheet1 where flag = 'Y' and scenario = 'CreatePUFail'";
		try
		{
			Recordset rs = connection.executeQuery(query);
			if(rs!=null)
			{
				while(rs.next())
				{
					String[] str = new String[5];
					str[0]=rs.getField("DeviceId");
					str[1]=rs.getField("AppInstanceId");
					str[2]=rs.getField("OpClientId");
					str[3]=rs.getField("username");
					str[4]=rs.getField("password");
					lst.add(str);
				}
			}
			Reporter.log("------ Getting Null values ------");
		}
		catch(NullPointerException e)
		{
			Reporter.log("------ Getting Null values ------");
		}
		catch(Exception e)
		{
			Reporter.log("------ Not Getting proper values ------");
		}
		return lst.iterator();
	}
	
	@DataProvider(name="dataCollection_BACNETIP")
	public Iterator<String[]> dataCollectionBACNETIP() throws FilloException
	{
		List<String[]> lst = new ArrayList<>();
		String query = "select DeviceId, AppInstanceId, OpClientId, username, password from sheet1 where flag = 'Y' and scenario = 'CreateBI'";
		try
		{
			Recordset rs = connection.executeQuery(query);
			if(rs!=null)
			{
				while(rs.next())
				{
					String[] str = new String[5];
					str[0]=rs.getField("DeviceId");
					str[1]=rs.getField("AppInstanceId");
					str[2]=rs.getField("OpClientId");
					str[3]=rs.getField("username");
					str[4]=rs.getField("password");
					lst.add(str);
				}
			}
			Reporter.log("------ Getting Null values ------");
		}
		catch(NullPointerException e)
		{
			Reporter.log("------ Getting Null values ------");
		}
		catch(Exception e)
		{
			Reporter.log("------ Not Getting proper values ------");
		}
		return lst.iterator();
	}
	
	@DataProvider(name="dataCollection_BACNETIP_Fail")
	public Iterator<String[]> dataCollectionBACNETIPFail() throws FilloException
	{
		List<String[]> lst = new ArrayList<>();
		String query = "select DeviceId, AppInstanceId, OpClientId, username, password from sheet1 where flag = 'Y' and scenario = 'CreateBIFail'";
		try
		{
			Recordset rs = connection.executeQuery(query);
			if(rs!=null)
			{
				while(rs.next())
				{
					String[] str = new String[5];
					str[0]=rs.getField("DeviceId");
					str[1]=rs.getField("AppInstanceId");
					str[2]=rs.getField("OpClientId");
					str[3]=rs.getField("username");
					str[4]=rs.getField("password");
					lst.add(str);
				}
			}
			Reporter.log("------ Getting Null values ------");
		}
		catch(NullPointerException e)
		{
			Reporter.log("------ Getting Null values ------");
		}
		catch(Exception e)
		{
			Reporter.log("------ Not Getting proper values ------");
		}
		return lst.iterator();
	}
	
	@DataProvider(name="dataCollection_CreateWebApp")
	public Iterator<String[]> dataCollectionTRANSPARENT() throws FilloException
	{
		List<String[]> lst = new ArrayList<>();
		String query = "select DeviceId, AppInstanceId, OpClientId, username, password from sheet1 where flag = 'Y' and scenario = 'CreateWebApp'";
		try
		{
			Recordset rs = connection.executeQuery(query);
			if(rs!=null)
			{
				while(rs.next())
				{
					String[] str = new String[5];
					str[0]=rs.getField("DeviceId");
					str[1]=rs.getField("AppInstanceId");
					str[2]=rs.getField("OpClientId");
					str[3]=rs.getField("username");
					str[4]=rs.getField("password");
					lst.add(str);
				}
			}
			Reporter.log("------ Getting Null values ------");
		}
		catch(NullPointerException e)
		{
			Reporter.log("------ Getting Null values ------");
		}
		catch(Exception e)
		{
			Reporter.log("------ Not Getting proper values ------");
		}
		return lst.iterator();
	}
	
	@DataProvider(name="dataCollection_CreateWebApp_Fail")
	public Iterator<String[]> dataCollectionTRANSPARENTFail() throws FilloException
	{
		List<String[]> lst = new ArrayList<>();
		String query = "select DeviceId, AppInstanceId, OpClientId, username, password from sheet1 where flag = 'Y' and scenario = 'CreateWebAppFail'";
		try
		{
			Recordset rs = connection.executeQuery(query);
			if(rs!=null)
			{
				while(rs.next())
				{
					String[] str = new String[5];
					str[0]=rs.getField("DeviceId");
					str[1]=rs.getField("AppInstanceId");
					str[2]=rs.getField("OpClientId");
					str[3]=rs.getField("username");
					str[4]=rs.getField("password");
					lst.add(str);
				}
			}
			Reporter.log("------ Getting Null values ------");
		}
		catch(NullPointerException e)
		{
			Reporter.log("------ Getting Null values ------");
		}
		catch(Exception e)
		{
			Reporter.log("------ Not Getting proper values ------");
		}
		return lst.iterator();
	}
	
	@DataProvider(name="dataCollection_WEBRDP")
	public Iterator<String[]> dataCollectionWEBRDP() throws FilloException
	{
		List<String[]> lst = new ArrayList<>();
		String query = "select DeviceId, AppInstanceId, OpClientId, username, password from sheet1 where flag = 'Y' and scenario = 'CreateWEBRDP'";
		try
		{
			Recordset rs = connection.executeQuery(query);
			if(rs!=null)
			{
				while(rs.next())
				{
					String[] str = new String[5];
					str[0]=rs.getField("DeviceId");
					str[1]=rs.getField("AppInstanceId");
					str[2]=rs.getField("OpClientId");
					str[3]=rs.getField("username");
					str[4]=rs.getField("password");
					lst.add(str);
				}
			}
			Reporter.log("------ Getting Null values ------");
		}
		catch(NullPointerException e)
		{
			Reporter.log("------ Getting Null values ------");
		}
		catch(Exception e)
		{
			Reporter.log("------ Not Getting proper values ------");
		}
		return lst.iterator();
	}
	
	@DataProvider(name="dataCollection_WEBRDP_Fail")
	public Iterator<String[]> dataCollectionWEBRDPFail() throws FilloException
	{
		List<String[]> lst = new ArrayList<>();
		String query = "select DeviceId, AppInstanceId, OpClientId, username, password from sheet1 where flag = 'Y' and scenario = 'CreateWEBRDPFail'";
		try
		{
			Recordset rs = connection.executeQuery(query);
			if(rs!=null)
			{
				while(rs.next())
				{
					String[] str = new String[5];
					str[0]=rs.getField("DeviceId");
					str[1]=rs.getField("AppInstanceId");
					str[2]=rs.getField("OpClientId");
					str[3]=rs.getField("username");
					str[4]=rs.getField("password");
					lst.add(str);
				}
			}
			Reporter.log("------ Getting Null values ------");
		}
		catch(NullPointerException e)
		{
			Reporter.log("------ Getting Null values ------");
		}
		catch(Exception e)
		{
			Reporter.log("------ Not Getting proper values ------");
		}
		return lst.iterator();
	}
	
	
}

// ----------------------------------------------------------------------------
// <copyright company="Siemens AG" file="CreateConnectionRequest.java">
//   Copyright © Siemens AG 2017. All rights reserved. Confidential.
// </copyright>
// ----------------------------------------------------------------------------
package com.crspng.ConnectionManagement.Pojo;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class CreateConnectionRequest {

	public String device_id;

	public Long application_instance_id;

	public Long operator_client_id;

	public WebCredentials webCredentials;

	public CreateConnectionRequest() {
		// NO-arg constructor
	}

	public String getDevice_id() {
		return device_id;
	}

	public void setDevice_id(String device_id) {
		this.device_id = device_id;
	}

	public Long getApplication_instance_id() {
		return application_instance_id;
	}

	public void setApplication_instance_id(Long application_instance_id) {
		this.application_instance_id = application_instance_id;
	}

	public Long getOperator_client_id() {
		return operator_client_id;
	}

	public void setOperator_client_id(Long operator_client_id) {
		this.operator_client_id = operator_client_id;
	}

	public WebCredentials getWebCredentials() {
		return webCredentials;
	}

	public void setWebCredentials(WebCredentials webCredentials) {
		this.webCredentials = webCredentials;
	}

	@Override
	public String toString() {
		return "CreateConnectionRequest{" +
				"device_id=" + device_id +
				", application_instance_id=" + application_instance_id +
				", operator_client_id=" + operator_client_id +
				", webCredentials=" + webCredentials +
				'}';
	}


	@Override
	public boolean equals(Object o) {
		if (this == o) return true;

		if (o == null || getClass() != o.getClass()) return false;

		CreateConnectionRequest that = (CreateConnectionRequest) o;

		return new EqualsBuilder()
				.append(device_id, that.device_id)
				.append(application_instance_id, that.application_instance_id)
				.append(operator_client_id, that.operator_client_id)
				.append(webCredentials, that.webCredentials)
				.isEquals();
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder(17, 37)
				.append(device_id)
				.append(application_instance_id)
				.append(operator_client_id)
				.append(webCredentials)
				.toHashCode();
	}
}

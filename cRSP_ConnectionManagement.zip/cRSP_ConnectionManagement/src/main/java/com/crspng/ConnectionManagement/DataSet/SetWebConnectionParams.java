package com.crspng.ConnectionManagement.DataSet;

import com.crspng.ConnectionManagement.Pojo.CreateConnectionRequest;
import com.crspng.ConnectionManagement.Pojo.WebCredentials;

public class SetWebConnectionParams
{
	
	public CreateConnectionRequest setParameters(String DeviceId, String AppInstanceId, String OpClientId, String username, String password)
	{
		CreateConnectionRequest connectionRequest=new CreateConnectionRequest();
		connectionRequest.setDevice_id(DeviceId);
		connectionRequest.setApplication_instance_id(Long.parseLong(AppInstanceId));
		connectionRequest.setOperator_client_id(Long.parseLong(OpClientId));
		WebCredentials credentials=new WebCredentials();
		credentials.setUser_name(username);
		credentials.setPassword(password);
		connectionRequest.setWebCredentials(credentials);
		return connectionRequest;
	}

}

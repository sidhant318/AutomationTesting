// ----------------------------------------------------------------------------
// <copyright company="Siemens AG" file="WebCredentials.java">
//   Copyright © Siemens AG 2017. All rights reserved. Confidential.
// </copyright>
// ----------------------------------------------------------------------------
package com.crspng.ConnectionManagement.Pojo;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

/**
 * Created by Devaraj Reddy, 6/13/2018 - 2:05 PM
 */
public class WebCredentials {
    private String user_name;
    private String password;

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "WebCredentials{" +
                "user_name='" + user_name + '\'' +
                ", password='" + password + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        WebCredentials that = (WebCredentials) o;

        return new EqualsBuilder()
                .append(user_name, that.user_name)
                .append(password, that.password)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(user_name)
                .append(password)
                .toHashCode();
    }
}
